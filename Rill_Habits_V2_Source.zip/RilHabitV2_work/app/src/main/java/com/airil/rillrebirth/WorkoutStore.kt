package com.airil.rillrebirth

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Lightweight local-only storage for RilHabit V2 workout and mood data. */
data class WorkoutSession(
    val id: Long,
    var name: String,
    var time: String,
    var durationMinutes: Int,
    var days: MutableSet<Int>, // Calendar.DAY_OF_WEEK values; empty means one-off date
    var oneOffDate: String,
    var notes: String,
    var reminder: Boolean,
    var active: Boolean,
    var exercises: MutableList<WorkoutExercise>
)

data class WorkoutExercise(var name: String, var sets: Int, var reps: String)

object WorkoutStore {
    private const val PREFS = "rill_data"
    private const val WORKOUTS = "workouts_v2_json"
    private const val WORKOUT_DONE = "workout_done_v2_json"
    private const val EXERCISE_CHECKS = "workout_exercise_checks_v2_json"
    private const val MOODS = "moods_v2_json"
    private const val XP_CLAIMS = "workout_xp_claims_v2_json"
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun today(): String = dateFmt.format(Date())
    fun date(offset: Int): String = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, offset) }.let { dateFmt.format(it.time) }
    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context): MutableList<WorkoutSession> {
        val raw = prefs(context).getString(WORKOUTS, null) ?: return mutableListOf()
        return try {
            val arr = JSONArray(raw); val result = mutableListOf<WorkoutSession>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val daysJson = o.optJSONArray("days") ?: JSONArray()
                val days = mutableSetOf<Int>(); for (j in 0 until daysJson.length()) days.add(daysJson.optInt(j))
                val exJson = o.optJSONArray("exercises") ?: JSONArray(); val exercises = mutableListOf<WorkoutExercise>()
                for (j in 0 until exJson.length()) { val e = exJson.getJSONObject(j); exercises.add(WorkoutExercise(e.optString("name"), e.optInt("sets", 3), e.optString("reps", "8–12"))) }
                result.add(WorkoutSession(o.optLong("id"), o.optString("name", "Workout"), o.optString("time", "18:00"), o.optInt("duration", 30), days, o.optString("date", ""), o.optString("notes", ""), o.optBoolean("reminder", false), o.optBoolean("active", true), exercises))
            }
            result
        } catch (_: Exception) { mutableListOf() }
    }

    fun save(context: Context, sessions: List<WorkoutSession>) {
        val arr = JSONArray()
        sessions.forEach { s ->
            val d = JSONArray(); s.days.sorted().forEach { d.put(it) }
            val e = JSONArray(); s.exercises.forEach { e.put(JSONObject().put("name", it.name).put("sets", it.sets).put("reps", it.reps)) }
            arr.put(JSONObject().put("id", s.id).put("name", s.name).put("time", s.time).put("duration", s.durationMinutes).put("days", d).put("date", s.oneOffDate).put("notes", s.notes).put("reminder", s.reminder).put("active", s.active).put("exercises", e))
        }
        prefs(context).edit().putString(WORKOUTS, arr.toString()).apply()
    }

    fun sessionsForDate(context: Context, date: String = today()): List<WorkoutSession> {
        val cal = Calendar.getInstance(); try { cal.time = dateFmt.parse(date) ?: Date() } catch (_: Exception) {}
        val weekday = cal.get(Calendar.DAY_OF_WEEK)
        return load(context).filter { it.active && (if (it.oneOffDate.isNotBlank()) it.oneOffDate == date else it.days.contains(weekday)) }.sortedBy { it.time }
    }

    private fun doneRoot(context: Context) = try { JSONObject(prefs(context).getString(WORKOUT_DONE, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    fun isDone(context: Context, id: Long, date: String = today()): Boolean = doneRoot(context).optJSONObject(date)?.optBoolean(id.toString(), false) ?: false
    fun setDone(context: Context, id: Long, done: Boolean, date: String = today()) {
        val p = prefs(context)
        val root = doneRoot(context); val day = root.optJSONObject(date) ?: JSONObject()
        day.put(id.toString(), done); root.put(date, day)
        val claims = try { JSONObject(p.getString(XP_CLAIMS, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val claimKey = "$date:$id"
        if (done && !claims.optBoolean(claimKey, false)) claims.put(claimKey, true)
        p.edit().putString(WORKOUT_DONE, root.toString()).putString(XP_CLAIMS, claims.toString()).apply()
    }
    fun totalWorkoutXp(context: Context): Int {
        val claims = try { JSONObject(prefs(context).getString(XP_CLAIMS, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        var total = 0; val it = claims.keys(); while (it.hasNext()) { val key = it.next(); if (claims.optBoolean(key, false)) total += 20 }; return total
    }
    fun workoutXpToday(context: Context): Int {
        val claims = try { JSONObject(prefs(context).getString(XP_CLAIMS, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        var total = 0; val it = claims.keys(); while (it.hasNext()) { val key = it.next(); if (key.startsWith("${today()}:") && claims.optBoolean(key, false)) total += 20 }; return total
    }
    fun completedIds(context: Context, date: String = today()): Set<Long> {
        val day = doneRoot(context).optJSONObject(date) ?: JSONObject(); val out = mutableSetOf<Long>(); val keys = day.keys()
        while (keys.hasNext()) { val k = keys.next(); if (day.optBoolean(k, false)) k.toLongOrNull()?.let { out.add(it) } }
        return out
    }
    fun exerciseChecks(context: Context, id: Long, date: String = today()): MutableSet<Int> {
        val root = try { JSONObject(prefs(context).getString(EXERCISE_CHECKS, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val arr = root.optJSONArray("$date:$id") ?: JSONArray(); val result = mutableSetOf<Int>(); for (i in 0 until arr.length()) result.add(arr.optInt(i)); return result
    }
    fun saveExerciseChecks(context: Context, id: Long, checks: Set<Int>, date: String = today()) {
        val p = prefs(context); val root = try { JSONObject(p.getString(EXERCISE_CHECKS, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val arr = JSONArray(); checks.sorted().forEach { arr.put(it) }; root.put("$date:$id", arr); p.edit().putString(EXERCISE_CHECKS, root.toString()).apply()
    }
    fun workoutDayActive(context: Context, date: String): Boolean = completedIds(context, date).isNotEmpty()
    fun currentStreak(context: Context): Int {
        var n = 0
        // A streak requires an activity on every calendar day; if today is not active yet, count back from yesterday.
        var offset = if (workoutDayActive(context, today())) 0 else -1
        while (offset > -4000) { if (!workoutDayActive(context, date(offset))) break; n++; offset-- }
        return n
    }
    fun bestStreak(context: Context): Int {
        val root = doneRoot(context); val keys = mutableListOf<String>(); val it = root.keys(); while (it.hasNext()) keys.add(it.next())
        val active = keys.filter { workoutDayActive(context, it) }.sorted(); var best = 0; var run = 0; var previous: String? = null
        active.forEach { d ->
            val consecutive = try { previous != null && dateFmt.parse(d)!!.time - dateFmt.parse(previous!!)!!.time == 86400000L } catch (_: Exception) { false }
            run = if (consecutive) run + 1 else 1; if (run > best) best = run; previous = d
        }
        return best
    }
    fun saveMood(context: Context, date: String, value: Int, note: String) {
        val p = prefs(context); val root = try { JSONObject(p.getString(MOODS, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        root.put(date, JSONObject().put("value", value.coerceIn(1, 5)).put("note", note).put("updated", System.currentTimeMillis()))
        p.edit().putString(MOODS, root.toString()).apply()
    }
    fun mood(context: Context, date: String): JSONObject? = try { JSONObject(prefs(context).getString(MOODS, "{}") ?: "{}").optJSONObject(date) } catch (_: Exception) { null }
    fun moods(context: Context): JSONObject = try { JSONObject(prefs(context).getString(MOODS, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
}
